import Foundation
import SwiftUI

// MARK: - DayRecord
struct DayRecord: Identifiable {
    let id: UUID
    let date: Date
    var workout: WorkoutSession?
    var meals: [MealEntry]
    
    var macroConsistencyScore: Double {
        guard let workout = workout else { return 0 }
        let totalCals = meals.reduce(0.0) { $0 + $1.calories }
        guard totalCals > 0 else { return 0 }
        let totalProt = meals.reduce(0.0) { $0 + $1.protein }
        let totalCarb = meals.reduce(0.0) { $0 + $1.carbs }
        let totalFat  = meals.reduce(0.0) { $0 + $1.fat }
        let protPct = totalProt * 4.0 / totalCals
        let carbPct = totalCarb * 4.0 / totalCals
        let fatPct  = totalFat  * 9.0 / totalCals
        let idealProt = 0.30
        let idealCarb = 0.40
        let idealFat  = 0.30
        let diff = abs(protPct - idealProt) + abs(carbPct - idealCarb) + abs(fatPct - idealFat)
        let score = max(0, 100 - (diff * 200))
        return score
    }
    
    var formattedDate: String {
        let f = DateFormatter()
        f.dateStyle = .short
        f.timeStyle = .none
        f.locale = Locale(identifier: "pt_BR")
        return f.string(from: date)
    }
    
    var weekdayLabel: String {
        let f = DateFormatter()
        f.dateFormat = "EEEE"
        f.locale = Locale(identifier: "pt_BR")
        return f.string(from: date).capitalized
    }
}

// MARK: - HistoryViewModel
@Observable
class HistoryViewModel {
    var records: [DayRecord] = []
    var showPaywall: Bool = false
    var hasShownPaywallForLimit: Bool = false
    
    let revenueCat = RevenueCatService.shared
    
    var freeLimitDays: Int { 7 }
    
    var isPro: Bool { revenueCat.isPro }
    
    enum SubscriptionStatus { case free, pro }
    var subscriptionStatus: SubscriptionStatus { isPro ? .pro : .free }
    
    var visibleRecords: [DayRecord] {
        let all = records.sorted { $0.date > $1.date }
        if isPro { return all }
        let cutoff = Calendar.current.date(byAdding: .day, value: -freeLimitDays, to: Date()) ?? Date()
        return all.filter { $0.date >= cutoff }
    }
    
    var lockedRecords: [DayRecord] {
        let all = records.sorted { $0.date > $1.date }
        let cutoff = Calendar.current.date(byAdding: .day, value: -freeLimitDays, to: Date()) ?? Date()
        return all.filter { $0.date < cutoff }
    }
    
    var hasLockedContent: Bool {
        lockedRecords.isEmpty == false
    }
    
    func loadRecords(workouts: [WorkoutSession], meals: [MealEntry]) {
        var map: [Date: (workout: WorkoutSession?, meals: [MealEntry])] = [:]
        let cal = Calendar.current
        
        for w in workouts {
            let day = cal.startOfDay(for: w.date)
            map[day] = (workout: w, meals: map[day]?.meals ?? [])
        }
        for m in meals {
            let day = cal.startOfDay(for: m.timestamp)
            var existing = map[day]
            if existing == nil {
                existing = (workout: nil, meals: [])
            }
            var mealsForDay = existing?.meals ?? []
            mealsForDay.append(m)
            map[day] = (workout: existing?.workout, meals: mealsForDay)
        }
        
        records = map.map { entry in
            DayRecord(id: UUID(), date: entry.key, workout: entry.value.workout, meals: entry.value.meals)
        }
    }
    
    func triggerPaywallIfNeeded() {
        guard !isPro, hasLockedContent, !hasShownPaywallForLimit else { return }
        showPaywall = true
        hasShownPaywallForLimit = true
    }
    
    func dismissPaywall() {
        showPaywall = false
    }
}

import Foundation

// MARK: - Persistence Service
// Wrapper for local persistence using SwiftData.

class PersistenceService {
    static let shared = PersistenceService()
    
    // TODO: add ModelContainer / ModelContext when iOS-only code is linked
    
    func save<T: Encodable>(_ object: T, key: String) {
        if let data = try? JSONEncoder().encode(object) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
    
    func load<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }
    
    func remove(key: String) {
        UserDefaults.standard.removeObject(forKey: key)
    }
}

import SwiftUI

@Observable
class NutritionViewModel {
    var target: MacroTarget
    var meals: [MealEntry]
    var lastWorkout: WorkoutSession?
    
    var totalProtein: Double {
        meals.reduce(0.0) { $0 + $1.protein }
    }
    
    var totalCarbs: Double {
        meals.reduce(0.0) { $0 + $1.carbs }
    }
    
    var totalFat: Double {
        meals.reduce(0.0) { $0 + $1.fat }
    }
    
    var totalCalories: Double {
        meals.reduce(0.0) { $0 + $1.calories }
    }
    
    var formulaVisible: Bool = false
    
    init(target: MacroTarget = MacroTarget(), meals: [MealEntry] = [], lastWorkout: WorkoutSession? = nil) {
        self.target = target
        self.meals = meals
        self.lastWorkout = lastWorkout
    }
    
    func addMeal(name: String, protein: Double, carbs: Double, fat: Double) {
        let meal = MealEntry(name: name, protein: protein, carbs: carbs, fat: fat)
        meals.append(meal)
    }
    
    func removeMeal(at offsets: IndexSet) {
        meals.remove(atOffsets: offsets)
    }
    
    func removeMeal(meal: MealEntry) {
        meals.removeAll { $0.id == meal.id }
    }
    
    func formulaBreakdown(profile: UserProfile) -> String {
        target.formulaBreakdown(goal: profile.goalEnum, activityLevel: profile.activityLevelEnum)
    }
    
    func progressPercent(current: Double, target: Double) -> Double {
        guard target > 0 else { return 0 }
        return min(current / target, 1.0)
    }
}

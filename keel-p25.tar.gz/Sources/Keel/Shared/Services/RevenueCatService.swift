import Foundation

#if !SKIP
import RevenueCat
#endif

// MARK: - RevenueCatService
// Abstracts RevenueCat SDK. All RevenueCat types are guarded with #if !SKIP.
// On Android (Skip transpile), methods are stubbed so UI can still compile.

@Observable
class RevenueCatService {
    static let shared = RevenueCatService()

    var offerings: [SubscriptionProduct] = []
    var isLoading: Bool = false
    var errorMessage: String? = nil

    // MARK: - Entitlements

    var hasHistoryUnlimited: Bool = false
    var hasAnalytics: Bool = false
    var hasExport: Bool = false
    var isPro: Bool { hasHistoryUnlimited && hasAnalytics && hasExport }

    // MARK: - Callbacks (for UI bindings)

    var onPurchaseCompleted: ((Bool, String?) -> Void)? = nil
    var onRestored: ((Bool, String?) -> Void)? = nil

    // MARK: - Configuration

    func configure(apiKey: String) {
        #if !SKIP
        Purchases.configure(withAPIKey: apiKey)
        Purchases.shared.delegate = self
        #endif
        Task { await fetchOfferings() }
    }

    // MARK: - Offerings

    func fetchOfferings() async {
        isLoading = true
        errorMessage = nil

        #if !SKIP
        do {
            let offerings = try await Purchases.shared.offerings()
            var products: [SubscriptionProduct] = []
            if let current = offerings.current {
                for package in current.availablePackages {
                    products.append(SubscriptionProduct(from: package))
                }
            }
            self.offerings = products.sorted { $0.isPopular && !$1.isPopular }
            isLoading = false
        } catch {
            self.errorMessage = error.localizedDescription
            isLoading = false
        }
        #else
        // Stub for Skip/Android
        self.offerings = [
            SubscriptionProduct(
                identifier: "keel_pro_monthly",
                title: "Keel Pro",
                price: "$7.99",
                period: "/month",
                features: ["Unlimited history", "Analytics", "Export data"],
                isPopular: true
            ),
            SubscriptionProduct(
                identifier: "keel_pro_yearly",
                title: "Keel Pro Annual",
                price: "$59.99",
                period: "/year",
                features: ["All monthly features", "2 months free", "Priority support"],
                isPopular: false
            )
        ]
        isLoading = false
        #endif
    }

    // MARK: - Purchase

    func purchase(product: SubscriptionProduct) async -> Bool {
        isLoading = true
        errorMessage = nil

        #if !SKIP
        guard let package = await findPackage(for: product.identifier) else {
            errorMessage = "Product not found"
            isLoading = false
            return false
        }
        do {
            let (_, customerInfo, _) = try await Purchases.shared.purchase(package: package)
            updateEntitlements(from: customerInfo)
            isLoading = false
            onPurchaseCompleted?(true, nil)
            return true
        } catch {
            errorMessage = error.localizedDescription
            isLoading = false
            onPurchaseCompleted?(false, error.localizedDescription)
            return false
        }
        #else
        // Simulate success on Android/Skip
        hasHistoryUnlimited = true
        hasAnalytics = true
        hasExport = true
        isLoading = false
        onPurchaseCompleted?(true, nil)
        return true
        #endif
    }

    // MARK: - Restore

    func restorePurchases() async -> Bool {
        isLoading = true
        errorMessage = nil

        #if !SKIP
        do {
            let customerInfo = try await Purchases.shared.restorePurchases()
            updateEntitlements(from: customerInfo)
            isLoading = false
            let success = isPro
            onRestored?(success, success ? nil : "No purchases to restore")
            return success
        } catch {
            errorMessage = error.localizedDescription
            isLoading = false
            onRestored?(false, error.localizedDescription)
            return false
        }
        #else
        hasHistoryUnlimited = true
        hasAnalytics = true
        hasExport = true
        isLoading = false
        onRestored?(true, nil)
        return true
        #endif
    }

    // MARK: - Refresh entitlements

    func refreshEntitlements() async {
        #if !SKIP
        do {
            let customerInfo = try await Purchases.shared.customerInfo()
            updateEntitlements(from: customerInfo)
        } catch {
            errorMessage = error.localizedDescription
        }
        #endif
    }

    // MARK: - Private helpers

    #if !SKIP
    private func findPackage(for identifier: String) async -> Package? {
        do {
            let offerings = try await Purchases.shared.offerings()
            guard let current = offerings.current else { return nil }
            return current.availablePackages.first { $0.storeProduct.productIdentifier == identifier }
        } catch {
            return nil
        }
    }

    private func updateEntitlements(from customerInfo: CustomerInfo) {
        hasHistoryUnlimited = customerInfo.entitlements["history_unlimited"]?.isActive == true
        hasAnalytics = customerInfo.entitlements["analytics"]?.isActive == true
        hasExport = customerInfo.entitlements["export"]?.isActive == true
    }
    #endif
}

// MARK: - SubscriptionProduct (platform-agnostic model)
struct SubscriptionProduct: Identifiable, Hashable {
    let id = UUID()
    let identifier: String
    let title: String
    let price: String
    let period: String
    let features: [String]
    let isPopular: Bool

    #if !SKIP
    init(from package: Package) {
        let product = package.storeProduct
        self.identifier = product.productIdentifier
        self.title = product.localizedTitle
        self.price = product.localizedPriceString
        self.period = product.subscriptionPeriod?.localizedPeriodString ?? "/month"
        self.features = Self.featuresFor(productId: product.productIdentifier)
        self.isPopular = product.productIdentifier.contains("yearly") || product.productIdentifier.contains("annual")
    }
    #endif

    init(identifier: String, title: String, price: String, period: String, features: [String], isPopular: Bool) {
        self.identifier = identifier
        self.title = title
        self.price = price
        self.period = period
        self.features = features
        self.isPopular = isPopular
    }

    static func featuresFor(productId: String) -> [String] {
        if productId.contains("yearly") || productId.contains("annual") {
            return ["All monthly features", "2 months free", "Priority support"]
        }
        return ["Unlimited history", "Analytics", "Export data"]
    }
}

#if !SKIP
// MARK: - PurchasesDelegate
extension RevenueCatService: PurchasesDelegate {
    func purchases(_ purchases: Purchases, receivedUpdated customerInfo: CustomerInfo) {
        updateEntitlements(from: customerInfo)
    }
}
#endif

#if !SKIP
// MARK: - Convenience for subscription period
private extension SubscriptionPeriod {
    var localizedPeriodString: String {
        switch unit {
        case .day: return "/day"
        case .week: return "/week"
        case .month: return "/month"
        case .year: return "/year"
        @unknown default: return "/period"
        }
    }
}
#endif

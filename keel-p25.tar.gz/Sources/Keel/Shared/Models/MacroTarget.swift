import Foundation
#if !SKIP
import SwiftData
#endif

#if !SKIP
@Model
#endif
class MacroTarget {
    var protein: Double
    var carbs: Double
    var fat: Double
    var calories: Double
    var date: Date
    var isActive: Bool
    
    init(protein: Double = 180, carbs: Double = 250, fat: Double = 70, calories: Double = 2400, date: Date = Date(), isActive: Bool = true) {
        self.protein = protein
        self.carbs = carbs
        self.fat = fat
        self.calories = calories
        self.date = date
        self.isActive = isActive
    }
    
    // Mifflin-St Jeor formula components exposed for transparency
    var bmr: Double { 10 * weight + 6.25 * heightCMLookup - 5 * age + 5 }
    
    // MARK: - Internal for calculation context only (not persisted)
    private var weight: Double = 70.0
    private var heightCMLookup: Double = 175.0
    private var age: Int = 30
    
    static func calculateTargets(weight: Double, height: Double, age: Int, isMale: Bool = true, goal: GoalType, activityLevel: ActivityLevel) -> MacroTarget {
        let sexAdjustment: Double = isMale ? 5 : -161
        let bmr = 10 * weight + 6.25 * height - 5 * Double(age) + sexAdjustment
        
        let activityMultipliers: [ActivityLevel: Double] = [
            .sedentary: 1.2,
            .light: 1.375,
            .moderate: 1.55,
            .active: 1.725,
            .veryActive: 1.9
        ]
        let tdee = bmr * (activityMultipliers[activityLevel] ?? 1.55)
        
        let calories: Double
        let proteinMultiplier: Double
        let fatPct: Double
        switch goal {
        case .cut:
            calories = tdee - 500
            proteinMultiplier = 2.2
            fatPct = 0.25
        case .maintenance:
            calories = tdee
            proteinMultiplier = 1.8
            fatPct = 0.30
        case .bulk:
            calories = tdee + 300
            proteinMultiplier = 2.0
            fatPct = 0.25
        }
        
        let protein = weight * proteinMultiplier
        let fat = (calories * fatPct) / 9.0
        let carbs = (calories - (protein * 4.0) - (fat * 9.0)) / 4.0
        
        var target = MacroTarget(protein: protein, carbs: carbs, fat: fat, calories: calories)
        target.weight = weight
        target.heightCMLookup = height
        target.age = age
        return target
    }
    
    func formulaBreakdown(goal: GoalType, activityLevel: ActivityLevel) -> String {
        "BMR = 10×\(Int(weight)) + 6.25×\(Int(heightCMLookup)) - 5×\(age) + 5 = \(Int(bmr)) kcal\nTDEE = \(Int(bmr)) × \(activityMultiplierText(activityLevel)) = \(Int(bmr * activityMultiplierFor(activityLevel))) kcal\nAjuste para \(goalText(goal)): \(calories) kcal\nP = \(Int(protein))g | C = \(Int(carbs))g | G = \(Int(fat))g"
    }
    
    private func activityMultiplierFor(_ level: ActivityLevel) -> Double {
        switch level {
        case .sedentary: return 1.2
        case .light: return 1.375
        case .moderate: return 1.55
        case .active: return 1.725
        case .veryActive: return 1.9
        }
    }
    
    private func activityMultiplierText(_ level: ActivityLevel) -> String {
        switch level {
        case .sedentary: return "1.2"
        case .light: return "1.375"
        case .moderate: return "1.55"
        case .active: return "1.725"
        case .veryActive: return "1.9"
        }
    }
    
    private func goalText(_ goal: GoalType) -> String {
        switch goal {
        case .cut: return "deficit"
        case .maintenance: return "manutenção"
        case .bulk: return "superávit"
        }
    }
}

enum GoalType: String, Codable {
    case cut = "cut"
    case maintenance = "maintenance"
    case bulk = "bulk"
}

enum ActivityLevel: String, Codable {
    case sedentary = "sedentary"
    case light = "light"
    case moderate = "moderate"
    case active = "active"
    case veryActive = "veryActive"
}

import Foundation
#if !SKIP
import SwiftData
#endif

#if !SKIP
@Model
#endif
class MealEntry {
    var name: String
    var protein: Double
    var carbs: Double
    var fat: Double
    var timestamp: Date
    var mealType: String // "Café da manhã", "Almoço", "Jantar", "Lanche"
    var id: String
    
    init(name: String = "", protein: Double = 0, carbs: Double = 0, fat: Double = 0, mealType: String = "Lanche") {
        self.name = name
        self.protein = protein
        self.carbs = carbs
        self.fat = fat
        self.timestamp = Date()
        self.mealType = mealType
        self.id = UUID().uuidString
    }
    
    var calories: Double {
        (protein * 4) + (carbs * 4) + (fat * 9)
    }
}

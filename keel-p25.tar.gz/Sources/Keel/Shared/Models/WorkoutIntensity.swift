import Foundation

enum WorkoutIntensity: String, Codable {
    case light = "Leve"
    case moderate = "Moderado"
    case heavy = "Pesado"
}

import SwiftUI
import SkipUI

#if !SKIP
import RevenueCat
import UIKit
#endif

@main
struct KeelApp: App {
    #if !SKIP
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    #endif

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

#if !SKIP
class AppDelegate: NSObject, UIApplicationDelegate {
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil
    ) -> Bool {
        // Configure RevenueCat with sandbox key (replace with production key for release)
        let revenueCatAPIKey = "appl_YOUR_SANDBOX_KEY"
        RevenueCatService.shared.configure(apiKey: revenueCatAPIKey)
        return true
    }
}
#endif

struct ContentView: View {
    var body: some View {
        NavigationStack {
            OnboardingView()
        }
        .preferredColorScheme(.dark)
    }
}

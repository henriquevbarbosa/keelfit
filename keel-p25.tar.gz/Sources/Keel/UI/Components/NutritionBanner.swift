import SwiftUI

struct NutritionBanner: View {
    let lastWorkout: WorkoutSession?
    
    private var message: String {
        guard let workout = lastWorkout else {
            return "Bora treinar? Registre seu treino para ajustar seus macros."
        }
        let calendar = Calendar.current
        let isToday = calendar.isDateInToday(workout.date)
        guard isToday else {
            return "Último treino: \(workout.formattedDate). Mantenha a consistência!"
        }
        switch workout.intensity {
        case WorkoutIntensity.heavy.rawValue:
            return "Treino intenso hoje — priorize proteína e carboidratos para recuperação."
        case WorkoutIntensity.light.rawValue:
            return "Treino leve — foque em proteínas e mantenha a dieta no alvo."
        default:
            return "Bom trabalho! Mantenha os macros no alvo."
        }
    }
    
    private var accentColor: Color {
        guard let workout = lastWorkout,
              Calendar.current.isDateInToday(workout.date) else {
            return Color(red: 0.420, green: 0.420, blue: 0.420)
        }
        switch workout.intensity {
        case WorkoutIntensity.heavy.rawValue:
            return Color(red: 1.0, green: 0.420, blue: 0.420)
        case WorkoutIntensity.light.rawValue:
            return Color(red: 0.306, green: 0.800, blue: 0.769)
        default:
            return Color(red: 0.784, green: 1.0, blue: 0.0)
        }
    }
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: bannerIcon)
                .font(.system(size: 20, weight: .semibold))
                .foregroundColor(accentColor)
            
            Text(message)
                .font(.system(size: 14, weight: .regular))
                .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                .lineLimit(2)
            
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color(red: 0.078, green: 0.078, blue: 0.078))
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color(red: 0.165, green: 0.165, blue: 0.165), lineWidth: 0.5)
        )
    }
    
    private var bannerIcon: String {
        guard let workout = lastWorkout else { return "figure.walk" }
        switch workout.intensity {
        case WorkoutIntensity.heavy.rawValue: return "flame.fill"
        case WorkoutIntensity.light.rawValue: return "leaf.fill"
        default: return "checkmark.seal.fill"
        }
    }
}

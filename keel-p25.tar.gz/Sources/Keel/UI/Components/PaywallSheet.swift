import SwiftUI
import SkipUI

// MARK: - Paywall Sheet (RevenueCat-driven)
struct PaywallSheet: View {
    @State private var revenueCat = RevenueCatService.shared
    @State private var isPurchasing = false
    @State private var purchaseError: String? = nil
    
    let onDismiss: () -> Void
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    VStack(spacing: 8) {
                        Image(systemName: "lock.shield.fill")
                            .font(.system(size: 48, weight: .regular))
                            .foregroundColor(Color(red: 0.784, green: 1.0, blue: 0.0))
                        Text("Histórico ilimitado")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(.white)
                        Text("Desbloqueie todos os seus dados de treino e nutrição")
                            .font(.system(size: 14, weight: .regular))
                            .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                            .multilineTextAlignment(.center)
                    }
                    .padding(.top, 24)
                    
                    if revenueCat.isLoading {
                        ProgressView()
                            .tint(Color(red: 0.784, green: 1.0, blue: 0.0))
                            .padding(.top, 40)
                    } else if revenueCat.offerings.isEmpty {
                        Text("Nenhum produto disponível")
                            .font(.system(size: 16, weight: .regular))
                            .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                            .padding(.top, 40)
                    } else {
                        ForEach(revenueCat.offerings) { product in
                            PaywallCard(
                                title: product.title,
                                price: product.price,
                                period: product.period,
                                features: product.features,
                                isPopular: product.isPopular,
                                action: { purchase(product: product) }
                            )
                        }
                    }
                    
                    if let error = purchaseError {
                        Text(error)
                            .font(.system(size: 14, weight: .regular))
                            .foregroundColor(Color(red: 1.0, green: 0.3, blue: 0.3))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 16)
                    }
                    
                    Button(action: restore) {
                        Text("Restaurar compras")
                            .font(.system(size: 14, weight: .regular))
                            .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                    }
                    .disabled(isPurchasing || revenueCat.isLoading)
                    .padding(.top, 8)
                }
                .padding(16)
            }
            .background(Color(red: 0.039, green: 0.039, blue: 0.039))
            .navigationTitle("Assinatura")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: onDismiss) {
                        Image(systemName: "xmark")
                            .foregroundColor(.white)
                    }
                }
            }
        }
        .preferredColorScheme(.dark)
    }
    
    // MARK: - Actions
    
    private func purchase(product: SubscriptionProduct) {
        guard !isPurchasing else { return }
        isPurchasing = true
        purchaseError = nil
        Task {
            let success = await revenueCat.purchase(product: product)
            isPurchasing = false
            if success {
                onDismiss()
            } else if let error = revenueCat.errorMessage {
                purchaseError = error
            }
        }
    }
    
    private func restore() {
        guard !isPurchasing else { return }
        isPurchasing = true
        purchaseError = nil
        Task {
            let success = await revenueCat.restorePurchases()
            isPurchasing = false
            if success {
                onDismiss()
            } else if let error = revenueCat.errorMessage {
                purchaseError = error
            }
        }
    }
}

// MARK: - Preview
#if !SKIP
#Preview("Paywall Sheet") {
    PaywallSheet(onDismiss: {})
        .preferredColorScheme(.dark)
}
#endif

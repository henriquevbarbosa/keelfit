import SwiftUI

struct WorkoutSetRow: View {
    let setNumber: Int
    @Binding var repsText: String
    @Binding var weightText: String
    let onDelete: () -> Void
    
    var body: some View {
        HStack(spacing: 8) {
            Text("\(setNumber)")
                .font(.system(size: 12, weight: .regular))
                .foregroundColor(Color(red: 0.420, green: 0.420, blue: 0.420))
                .frame(width: 24, alignment: .center)
            
            TextField("0", text: $repsText)
                .font(.system(size: 16, weight: .medium))
                .keyboardType(.numberPad)
                .multilineTextAlignment(.center)
                .frame(width: 50)
                .padding(4)
                .background(Color(red: 0.078, green: 0.078, blue: 0.078))
                .cornerRadius(4)
            
            Text("×")
                .font(.system(size: 12, weight: .regular))
                .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
            
            TextField("0.0", text: $weightText)
                .font(.system(size: 16, weight: .medium))
                .keyboardType(.decimalPad)
                .multilineTextAlignment(.center)
                .frame(width: 60)
                .padding(4)
                .background(Color(red: 0.078, green: 0.078, blue: 0.078))
                .cornerRadius(4)
            
            Text("kg")
                .font(.system(size: 12, weight: .regular))
                .foregroundColor(Color(red: 0.420, green: 0.420, blue: 0.420))
            
            Spacer()
            
            Button(action: onDelete) {
                Image(systemName: "minus.circle.fill")
                    .foregroundColor(Color(red: 1.0, green: 0.322, blue: 0.322))
                    .font(.system(size: 20, weight: .regular))
            }
            .buttonStyle(.plain)
        }
        .frame(minHeight: 44)
    }
}

#if !SKIP
#Preview {
    struct WorkoutSetRowPreview: View {
        @State var repsText = "10"
        @State var weightText = "60.0"
        
        var body: some View {
            WorkoutSetRow(setNumber: 1, repsText: $repsText, weightText: $weightText, onDelete: {})
                .padding()
                .background(Color(red: 0.039, green: 0.039, blue: 0.039))
        }
    }
    WorkoutSetRowPreview()
}
#endif

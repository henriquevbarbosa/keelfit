import SwiftUI

struct MealInputRow: View {
    @Binding var name: String
    @Binding var proteinText: String
    @Binding var carbsText: String
    @Binding var fatText: String
    var onAdd: () -> Void
    
    private var isValid: Bool {
        let p = Double(proteinText) ?? 0
        let c = Double(carbsText) ?? 0
        let f = Double(fatText) ?? 0
        return !name.isEmpty && (p + c + f) > 0
    }
    
    var body: some View {
        VStack(spacing: 12) {
            TextField("Nome da refeição", text: $name)
                .font(.system(size: 16, weight: .regular))
                .foregroundColor(Color(red: 1.0, green: 1.0, blue: 1.0))
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(Color(red: 0.078, green: 0.078, blue: 0.078))
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color(red: 0.165, green: 0.165, blue: 0.165), lineWidth: 0.5)
                )
            
            HStack(spacing: 8) {
                macroTextField("P (g)", text: $proteinText)
                macroTextField("C (g)", text: $carbsText)
                macroTextField("G (g)", text: $fatText)
            }
            
            PrimaryButton(title: "Adicionar refeição", action: onAdd)
                .disabled(!isValid)
                .opacity(isValid ? 1.0 : 0.5)
        }
        .padding(16)
        .background(Color(red: 0.141, green: 0.141, blue: 0.141))
        .cornerRadius(12)
    }
    
    private func macroTextField(_ label: String, text: Binding<String>) -> some View {
        HStack(spacing: 4) {
            TextField(label, text: text)
                .keyboardType(.decimalPad)
                .font(.system(size: 14, weight: .regular))
                .foregroundColor(Color(red: 1.0, green: 1.0, blue: 1.0))
                .multilineTextAlignment(.center)
                .padding(.vertical, 8)
        }
        .background(Color(red: 0.078, green: 0.078, blue: 0.078))
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color(red: 0.165, green: 0.165, blue: 0.165), lineWidth: 0.5)
        )
    }
}

#if !SKIP
#Preview {
    struct PreviewWrapper: View {
        @State var name = ""
        @State var p = "30"
        @State var c = "45"
        @State var f = "12"
        var body: some View {
            MealInputRow(
                name: $name,
                proteinText: $p,
                carbsText: $c,
                fatText: $f,
                onAdd: {}
            )
            .padding()
            .background(Color(red: 0.039, green: 0.039, blue: 0.039))
        }
    }
    PreviewWrapper()
}
#endif

import SwiftUI
import SkipUI

struct HistoryView: View {
    @State private var viewModel = HistoryViewModel()
    @State private var expandedRecordID: UUID? = nil
    
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                header
                recordList
                if viewModel.hasLockedContent && viewModel.subscriptionStatus == .free {
                    paywallHint
                }
            }
        }
        .background(Color(red: 0.039, green: 0.039, blue: 0.039))
        .onAppear(perform: loadMockIfEmpty)
        .sheet(isPresented: $viewModel.showPaywall) {
            PaywallSheet(onDismiss: { viewModel.dismissPaywall() })
        }
    }
    
    // MARK: - Header
    private var header: some View {
        VStack(spacing: 8) {
            HStack {
                Text("Histórico")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(.white)
                Spacer()
                if viewModel.subscriptionStatus == .pro {
                    Text("PRO")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(Color(red: 0.039, green: 0.039, blue: 0.039))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color(red: 0.784, green: 1.0, blue: 0.0))
                        .cornerRadius(4)
                } else {
                    Text("7 dias grátis")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .overlay(
                            RoundedRectangle(cornerRadius: 4)
                                .stroke(Color(red: 0.2, green: 0.2, blue: 0.2), lineWidth: 1)
                        )
                }
            }
            
            if let first = viewModel.visibleRecords.first, let workout = first.workout {
                HStack(spacing: 16) {
                    Label(viewModel.visibleRecords.filter { $0.workout != nil }.count.description + " treinos", systemImage: "figure.strengthtraining.traditional")
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                    Label(Int(workout.totalVolume).description + " kg", systemImage: "scalemass")
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                    Spacer()
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 16)
        .padding(.bottom, 12)
    }
    
    // MARK: - Record List
    private var recordList: some View {
        LazyVStack(spacing: 12) {
            ForEach(viewModel.visibleRecords) { record in
                RecordCard(
                    record: record,
                    isExpanded: expandedRecordID == record.id,
                    onTap: {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            if expandedRecordID == record.id {
                                expandedRecordID = nil
                            } else {
                                expandedRecordID = record.id
                            }
                        }
                    }
                )
            }
            
            if viewModel.subscriptionStatus == .free && viewModel.hasLockedContent {
                lockedRow
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }
    
    // MARK: - Locked Row (Paywall Gate)
    private var lockedRow: some View {
        Button(action: {
            viewModel.triggerPaywallIfNeeded()
        }) {
            HStack(spacing: 12) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                VStack(alignment: .leading, spacing: 2) {
                    Text("\(viewModel.lockedRecords.count) dias anteriores bloqueados")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                    Text("Assine Keel Pro para ver o histórico completo")
                        .font(.system(size: 12, weight: .regular))
                        .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Color(red: 0.784, green: 1.0, blue: 0.0))
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 14)
            .background(Color(red: 0.078, green: 0.078, blue: 0.078))
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color(red: 0.784, green: 1.0, blue: 0.0).opacity(0.3), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .onAppear {
            viewModel.triggerPaywallIfNeeded()
        }
    }
    
    // MARK: - Paywall Hint Footer
    private var paywallHint: some View {
        VStack(spacing: 8) {
            Text("Histórico ilimitado com Keel Pro")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.white)
            Text("Visualize análises completas de todos os seus treinos e refeições")
                .font(.system(size: 12, weight: .regular))
                .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                .multilineTextAlignment(.center)
            PrimaryButton(title: "Desbloquear histórico", action: {
                viewModel.showPaywall = true
            })
            .padding(.top, 4)
        }
        .padding(16)
        .background(Color(red: 0.102, green: 0.102, blue: 0.102))
        .cornerRadius(12)
        .padding(.horizontal, 16)
        .padding(.bottom, 24)
    }
    
    // MARK: - Mock Load
    private func loadMockIfEmpty() {
        guard viewModel.records.isEmpty else { return }
        let cal = Calendar.current
        let today = cal.startOfDay(for: Date())
        var workouts: [WorkoutSession] = []
        var meals: [MealEntry] = []
        
        for dayOffset in 0..<14 {
            guard let date = cal.date(byAdding: .day, value: -dayOffset, to: today) else { continue }
            let isWorkoutDay = dayOffset % 2 == 0
            if isWorkoutDay {
                let sets = [
                    SetEntry(reps: 10, weight: 60.0, unit: "kg"),
                    SetEntry(reps: 8, weight: 65.0, unit: "kg"),
                    SetEntry(reps: 8, weight: 65.0, unit: "kg")
                ]
                let exercise = ExerciseLog(exerciseID: "supino", exerciseName: "Supino Reto", muscleGroup: "Peito", sets: sets)
                let session = WorkoutSession(date: cal.date(byAdding: .hour, value: 18, to: date) ?? date, exercises: [exercise], duration: 3600, notes: "", intensity: "Pesado")
                workouts.append(session)
            }
            let m1 = MealEntry(name: "Ovos + Torrada", protein: 20, carbs: 30, fat: 12)
            m1.timestamp = cal.date(byAdding: .hour, value: 8, to: date) ?? date
            let m2 = MealEntry(name: "Arroz + Frango", protein: 35, carbs: 60, fat: 8)
            m2.timestamp = cal.date(byAdding: .hour, value: 12, to: date) ?? date
            let m3 = MealEntry(name: "Whey", protein: 25, carbs: 5, fat: 2)
            m3.timestamp = cal.date(byAdding: .hour, value: 20, to: date) ?? date
            meals.append(contentsOf: [m1, m2, m3])
        }
        
        viewModel.loadRecords(workouts: workouts, meals: meals)
    }
}

// MARK: - Record Card
struct RecordCard: View {
    let record: DayRecord
    let isExpanded: Bool
    let onTap: () -> Void
    
    var body: some View {
        VStack(spacing: 0) {
            Button(action: onTap) {
                HStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(record.formattedDate)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                        Text(record.weekdayLabel)
                            .font(.system(size: 12, weight: .regular))
                            .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                    }
                    Spacer()
                    if let workout = record.workout {
                        VStack(alignment: .trailing, spacing: 2) {
                            Text("\(Int(workout.totalVolume)) kg")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(Color(red: 0.784, green: 1.0, blue: 0.0))
                            Text("\(workout.totalSets) séries")
                                .font(.system(size: 12, weight: .regular))
                                .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                        }
                    } else {
                        Text("Descanso")
                            .font(.system(size: 12, weight: .regular))
                            .foregroundColor(Color(red: 0.420, green: 0.420, blue: 0.420))
                    }
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 14)
            }
            .buttonStyle(.plain)
            
            if isExpanded {
                expandedContent
                    .padding(.horizontal, 12)
                    .padding(.bottom, 14)
            }
        }
        .background(Color(red: 0.078, green: 0.078, blue: 0.078))
        .cornerRadius(12)
    }
    
    private var expandedContent: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Macro consistency score
            HStack(spacing: 8) {
                Image(systemName: "chart.bar.fill")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Color(red: 0.0, green: 0.902, blue: 0.463))
                Text("Score de consistência: \(Int(record.macroConsistencyScore))/100")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                Spacer()
            }
            
            // Meal summary
            if !record.meals.isEmpty {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Refeições")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                    ForEach(record.meals.prefix(4), id: \.id) { meal in
                        HStack {
                            Text(meal.name)
                                .font(.system(size: 14, weight: .regular))
                                .foregroundColor(.white)
                            Spacer()
                            Text("\(Int(meal.calories)) kcal")
                                .font(.system(size: 12, weight: .regular))
                                .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                        }
                    }
                    let totalCals = record.meals.reduce(0.0) { $0 + $1.calories }
                    HStack {
                        Text("Total")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(Color(red: 0.784, green: 1.0, blue: 0.0))
                        Spacer()
                        Text("\(Int(totalCals)) kcal")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(Color(red: 0.784, green: 1.0, blue: 0.0))
                    }
                    .padding(.top, 2)
                }
            }
            
            // Workout detail
            if let workout = record.workout {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Treino")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                    ForEach(workout.exercises.prefix(3), id: \.exerciseID) { ex in
                        HStack {
                            Text(ex.exerciseName)
                                .font(.system(size: 14, weight: .regular))
                                .foregroundColor(.white)
                            Spacer()
                            Text("\(ex.totalSets) × \(Int(ex.totalVolume / max(Double(ex.totalSets), 1))) kg")
                                .font(.system(size: 12, weight: .regular))
                                .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                        }
                    }
                    HStack {
                        Text("Duração")
                            .font(.system(size: 12, weight: .regular))
                            .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                        Spacer()
                        Text("\(Int(workout.duration / 60)) min")
                            .font(.system(size: 12, weight: .regular))
                            .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                    }
                    .padding(.top, 2)
                }
            }
        }
    }
}

// MARK: - Previews
#if !SKIP
#Preview("Free mode with paywall hint") {
    HistoryView()
        .preferredColorScheme(.dark)
}
#endif

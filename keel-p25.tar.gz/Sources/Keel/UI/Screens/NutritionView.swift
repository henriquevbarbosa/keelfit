import SwiftUI

struct NutritionView: View {
    @State private var viewModel = NutritionViewModel()
    @State private var profile: UserProfile? = nil
    
    @State private var mealName: String = ""
    @State private var proteinText: String = ""
    @State private var carbsText: String = ""
    @State private var fatText: String = ""
    
    private var isValid: Bool {
        let p = Double(proteinText) ?? 0
        let c = Double(carbsText) ?? 0
        let f = Double(fatText) ?? 0
        return !mealName.isEmpty && (p + c + f) > 0
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                bannerSection
                macroProgressSection
                mealInputSection
                mealListSection
                formulaSection
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 20)
        }
        .background(Color(red: 0.039, green: 0.039, blue: 0.039))
        .onAppear(perform: loadProfile)
    }
    
    // MARK: - Sections
    
    private var bannerSection: some View {
        NutritionBanner(lastWorkout: viewModel.lastWorkout)
    }
    
    private var macroProgressSection: some View {
        VStack(spacing: 16) {
            HStack {
                Text("Macros de hoje")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundColor(Color(red: 1.0, green: 1.0, blue: 1.0))
                Spacer()
                Text("\(Int(viewModel.totalCalories)) kcal")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
            }
            
            VStack(spacing: 12) {
                MacroProgressBar(
                    label: "Proteína",
                    current: viewModel.totalProtein,
                    target: viewModel.target.protein,
                    color: Color(red: 1.0, green: 0.420, blue: 0.420)
                )
                MacroProgressBar(
                    label: "Carboidratos",
                    current: viewModel.totalCarbs,
                    target: viewModel.target.carbs,
                    color: Color(red: 0.306, green: 0.800, blue: 0.769)
                )
                MacroProgressBar(
                    label: "Gordura",
                    current: viewModel.totalFat,
                    target: viewModel.target.fat,
                    color: Color(red: 1.0, green: 0.898, blue: 0.427)
                )
            }
        }
        .padding(16)
        .background(Color(red: 0.141, green: 0.141, blue: 0.141))
        .cornerRadius(12)
    }
    
    private var mealInputSection: some View {
        VStack(spacing: 16) {
            HStack {
                Text("Adicionar refeição")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(Color(red: 1.0, green: 1.0, blue: 1.0))
                Spacer()
            }
            
            MealInputRow(
                name: $mealName,
                proteinText: $proteinText,
                carbsText: $carbsText,
                fatText: $fatText,
                onAdd: addMeal
            )
        }
    }
    
    private var mealListSection: some View {
        VStack(spacing: 16) {
            HStack {
                Text("Refeições de hoje")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(Color(red: 1.0, green: 1.0, blue: 1.0))
                Spacer()
                Text("\(viewModel.meals.count)")
                    .font(.system(size: 14, weight: .regular))
                    .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
            }
            
            if viewModel.meals.isEmpty {
                Text("Nenhuma refeição registrada ainda")
                    .font(.system(size: 14, weight: .regular))
                    .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.vertical, 24)
            } else {
                LazyVStack(spacing: 8) {
                    ForEach(viewModel.meals, id: \.id) { meal in
                        mealRow(meal)
                    }
                }
            }
        }
        .padding(16)
        .background(Color(red: 0.141, green: 0.141, blue: 0.141))
        .cornerRadius(12)
    }
    
    private func mealRow(_ meal: MealEntry) -> some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(meal.name)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(Color(red: 1.0, green: 1.0, blue: 1.0))
                Text("P: \(Int(meal.protein))g · C: \(Int(meal.carbs))g · G: \(Int(meal.fat))g · \(Int(meal.calories)) kcal")
                    .font(.system(size: 12, weight: .regular))
                    .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
            }
            Spacer()
            Button(action: { removeMeal(meal) }) {
                Image(systemName: "trash")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Color(red: 1.0, green: 0.420, blue: 0.420))
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(Color(red: 0.078, green: 0.078, blue: 0.078))
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color(red: 0.165, green: 0.165, blue: 0.165), lineWidth: 0.5)
        )
    }
    
    private var formulaSection: some View {
        VStack(spacing: 12) {
            Button(action: { viewModel.formulaVisible.toggle() }) {
                HStack {
                    Text("Fórmula de cálculo")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(Color(red: 1.0, green: 1.0, blue: 1.0))
                    Spacer()
                    Image(systemName: viewModel.formulaVisible ? "chevron.up" : "chevron.down")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(Color(red: 0.784, green: 1.0, blue: 0.0))
                }
            }
            .buttonStyle(.plain)
            
            if viewModel.formulaVisible, let p = profile {
                Text(viewModel.formulaBreakdown(profile: p))
                    .font(.system(size: 13, weight: .regular, design: .monospaced))
                    .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                    .lineSpacing(4)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(12)
                    .background(Color(red: 0.078, green: 0.078, blue: 0.078))
                    .cornerRadius(8)
            }
        }
        .padding(16)
        .background(Color(red: 0.141, green: 0.141, blue: 0.141))
        .cornerRadius(12)
    }
    
    // MARK: - Actions
    
    private func addMeal() {
        guard isValid else { return }
        let p = Double(proteinText) ?? 0
        let c = Double(carbsText) ?? 0
        let f = Double(fatText) ?? 0
        viewModel.addMeal(name: mealName, protein: p, carbs: c, fat: f)
        mealName = ""
        proteinText = ""
        carbsText = ""
        fatText = ""
    }
    
    private func removeMeal(_ meal: MealEntry) {
        viewModel.removeMeal(meal: meal)
    }
    
    private func loadProfile() {
        let service = PersistenceService.shared
        if let loaded: UserProfile = service.load(UserProfile.self, key: "user_profile") {
            profile = loaded
            viewModel.target = MacroTarget.calculateTargets(
                weight: loaded.weight,
                height: loaded.height,
                age: loaded.age,
                isMale: true,
                goal: loaded.goalEnum,
                activityLevel: loaded.activityLevelEnum
            )
        }
        
        if let sessions: [WorkoutSession] = service.load([WorkoutSession].self, key: "workout_sessions") {
            viewModel.lastWorkout = sessions.sorted(by: { $0.date > $1.date }).first
        }
    }
}

#if !SKIP
#Preview("Empty") {
    NutritionView()
        .preferredColorScheme(.dark)
}
#endif

import SwiftUI
import SkipUI

struct SettingsView: View {
    @State private var revenueCat = RevenueCatService.shared
    @State private var isRestoring = false
    @State private var restoreMessage: String? = nil
    @State private var showRestoreAlert = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                header
                subscriptionSection
                restoreSection
                aboutSection
            }
        }
        .background(Color(red: 0.039, green: 0.039, blue: 0.039))
        .navigationTitle("Configurações")
        .navigationBarTitleDisplayMode(.large)
        .alert("Restaurar Compras", isPresented: $showRestoreAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(restoreMessage ?? "")
        }
    }
    
    // MARK: - Header
    private var header: some View {
        VStack(spacing: 8) {
            HStack {
                Text("Configurações")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(.white)
                Spacer()
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 16)
        .padding(.bottom, 12)
    }
    
    // MARK: - Subscription Status
    private var subscriptionSection: some View {
        VStack(spacing: 16) {
            if revenueCat.isPro {
                proStatusCard
            } else {
                freeStatusCard
            }
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 16)
    }
    
    private var proStatusCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: "crown.fill")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(Color(red: 0.784, green: 1.0, blue: 0.0))
                Text("Keel Pro Ativo")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.white)
                Spacer()
            }
            
            VStack(alignment: .leading, spacing: 6) {
                entitlementRow(icon: "infinite", text: "Histórico ilimitado", active: revenueCat.hasHistoryUnlimited)
                entitlementRow(icon: "chart.bar.fill", text: "Análises avançadas", active: revenueCat.hasAnalytics)
                entitlementRow(icon: "square.and.arrow.up.fill", text: "Exportar dados", active: revenueCat.hasExport)
            }
        }
        .padding(16)
        .background(Color(red: 0.102, green: 0.102, blue: 0.102))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color(red: 0.784, green: 1.0, blue: 0.0).opacity(0.3), lineWidth: 1)
        )
    }
    
    private var freeStatusCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: "person.fill")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                Text("Plano Gratuito")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.white)
                Spacer()
            }
            
            Text("Histórico limitado a 7 dias. Assine Keel Pro para desbloquear todas as funcionalidades.")
                .font(.system(size: 14, weight: .regular))
                .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                .multilineTextAlignment(.leading)
            
            PrimaryButton(title: "Fazer upgrade") {
                // Navigate to paywall — in a real app this would present the paywall sheet
            }
        }
        .padding(16)
        .background(Color(red: 0.102, green: 0.102, blue: 0.102))
        .cornerRadius(12)
    }
    
    private func entitlementRow(icon: String, text: String, active: Bool) -> some View {
        HStack(spacing: 8) {
            Image(systemName: active ? "checkmark.circle.fill" : "xmark.circle.fill")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(active ? Color(red: 0.0, green: 0.902, blue: 0.463) : Color(red: 0.627, green: 0.627, blue: 0.627))
            Text(text)
                .font(.system(size: 14, weight: .regular))
                .foregroundColor(active ? .white : Color(red: 0.627, green: 0.627, blue: 0.627))
            Spacer()
        }
    }
    
    // MARK: - Restore Purchases
    private var restoreSection: some View {
        VStack(spacing: 0) {
            Button(action: restorePurchases) {
                HStack(spacing: 12) {
                    Image(systemName: "arrow.clockwise.circle.fill")
                        .font(.system(size: 20, weight: .regular))
                        .foregroundColor(Color(red: 0.784, green: 1.0, blue: 0.0))
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Restaurar compras")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                        Text("Recupere assinaturas anteriores")
                            .font(.system(size: 12, weight: .regular))
                            .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                    }
                    Spacer()
                    if isRestoring {
                        ProgressView()
                            .tint(Color(red: 0.784, green: 1.0, blue: 0.0))
                    } else {
                        Image(systemName: "chevron.right")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
            }
            .buttonStyle(.plain)
            .background(Color(red: 0.078, green: 0.078, blue: 0.078))
            .cornerRadius(12)
            .disabled(isRestoring)
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 16)
    }
    
    // MARK: - About
    private var aboutSection: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Image(systemName: "info.circle.fill")
                    .font(.system(size: 20, weight: .regular))
                    .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                VStack(alignment: .leading, spacing: 2) {
                    Text("Sobre")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                    Text("Keel v1.0 · Fitness tracker")
                        .font(.system(size: 12, weight: .regular))
                        .foregroundColor(Color(red: 0.627, green: 0.627, blue: 0.627))
                }
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .background(Color(red: 0.078, green: 0.078, blue: 0.078))
            .cornerRadius(12)
        }
        .padding(.horizontal, 16)
    }
    
    // MARK: - Actions
    private func restorePurchases() {
        guard !isRestoring else { return }
        isRestoring = true
        restoreMessage = nil
        Task {
            let success = await revenueCat.restorePurchases()
            isRestoring = false
            restoreMessage = success
                ? "Compras restauradas com sucesso!"
                : (revenueCat.errorMessage ?? "Nenhuma compra encontrada para restaurar.")
            showRestoreAlert = true
        }
    }
}

// MARK: - Preview
#if !SKIP
#Preview("Settings - Free") {
    NavigationStack {
        SettingsView()
    }
    .preferredColorScheme(.dark)
}

#Preview("Settings - Pro") {
    let service = RevenueCatService.shared
    service.hasHistoryUnlimited = true
    service.hasAnalytics = true
    service.hasExport = true
    return NavigationStack {
        SettingsView()
    }
    .preferredColorScheme(.dark)
}
#endif
